﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using ZXing.Mobile;
using System.Diagnostics;
using ZXing;

namespace SmartTollpay
{
    public partial class ScanCode : PhoneApplicationPage
    {
        private MobileBarcodeScanner _scanner;

        public ScanCode()
        {

            InitializeComponent();

            _scanner = new MobileBarcodeScanner(this.Dispatcher);
            _scanner.Dispatcher = this.Dispatcher;

        }


        private void HandleScanResult(Result result)
        {
            string msg = "";
            if (result != null)
                msg = "Your payment of ₹ 60 at Electronic City Flyover is successful";
            else
                msg = "Scan Failed! Try again";

            this.Dispatcher.BeginInvoke(() => {
                MessageBox.Show(msg);
                NavigationService.Navigate(new Uri("/Switchboard.xaml", UriKind.RelativeOrAbsolute));
            });
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                _scanner.UseCustomOverlay = false;
                _scanner.TopText = "Hold camera up to QR code";
                _scanner.BottomText = "Camera will automatically scan QR code\r\n\rPress the 'Back' button to cancel";

                _scanner.Scan().ContinueWith(t =>
                {
                    if (t.Result != null)
                        HandleScanResult(t.Result);
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

        }

    }
}