﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace SmartTollpay
{
    public partial class ViewHistory : PhoneApplicationPage
    {
        public ViewHistory()
        {
            InitializeComponent();
            this.Loaded += ViewHistory_Loaded;
        }

        private void ViewHistory_Loaded(object sender, RoutedEventArgs e)
        {

            lbx.ItemsSource = new List<TollDetail> {
                new TollDetail { DateAndTime="14-05-2016 09:03", TollBooth="Electronic City Flyover Toll Plaza", TollAmount="₹ 60" },
                new TollDetail { DateAndTime="13-05-2016 18:31", TollBooth="Mysuru Road Toll Plaza", TollAmount="₹ 40" },
                new TollDetail { DateAndTime="12-05-2016 08:55", TollBooth="Electronic City Flyover Toll Plaza", TollAmount="₹ 60" },
                new TollDetail { DateAndTime="11-05-2016 17:45", TollBooth="Nice Road Toll Plaza", TollAmount="₹ 50" },
                new TollDetail { DateAndTime="10-05-2016 05:15", TollBooth="Devanahalli Airport Toll ", TollAmount="₹ 120" },
                new TollDetail { DateAndTime="10-05-2016 11:03", TollBooth="Electronic City Flyover Toll Plaza", TollAmount="₹ 60" }
            };
        }
    }

    public class TollDetail
    {
        public string DateAndTime { get; set; }
        public string TollBooth { get; set; }
        public string TollAmount { get; set; }
    }

}