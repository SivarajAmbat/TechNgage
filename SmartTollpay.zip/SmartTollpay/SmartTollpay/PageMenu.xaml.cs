﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace SmartTollpay
{
    public partial class PageMenu : PhoneApplicationPage
    {
        public PageMenu()
        {
            InitializeComponent();
            this.Loaded += PageMenu_Loaded;
        }

        private void PageMenu_Loaded(object sender, RoutedEventArgs e)
        {
            //HubTileService.FreezeGroup("MenuOptions");
        }

        private void HubTile_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            /* View Balance */
            NavigationService.Navigate(new Uri("/CheckBalance.xaml", UriKind.RelativeOrAbsolute));

        }

        private void HubTile_Tap_1(object sender, System.Windows.Input.GestureEventArgs e)
        {
            /* Recharge Account */
            NavigationService.Navigate(new Uri("/RechargeAccount.xaml", UriKind.RelativeOrAbsolute));

        }

        private void HubTile_Tap_2(object sender, System.Windows.Input.GestureEventArgs e)
        {
            /* Scan Code */
            NavigationService.Navigate(new Uri("/ScanCode.xaml", UriKind.RelativeOrAbsolute));

        }

        private void HubTile_Tap_3(object sender, System.Windows.Input.GestureEventArgs e)
        {
            /* View History */
            NavigationService.Navigate(new Uri("/ViewHistory.xaml", UriKind.RelativeOrAbsolute));

        }

        private void HubTile_Tap_4(object sender, System.Windows.Input.GestureEventArgs e)
        {
            /* Check Toll */
            NavigationService.Navigate(new Uri("/CheckToll.xaml", UriKind.RelativeOrAbsolute));

        }

        private void HubTile_Tap_5(object sender, System.Windows.Input.GestureEventArgs e)
        {
            /* Preferences */
            NavigationService.Navigate(new Uri("/Preferences.xaml", UriKind.RelativeOrAbsolute));

        }
    }
}