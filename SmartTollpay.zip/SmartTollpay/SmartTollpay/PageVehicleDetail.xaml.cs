﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace SmartTollpay
{
    public partial class PageVehicleDetail : PhoneApplicationPage
    {
        public PageVehicleDetail()
        {
            InitializeComponent();
        }

        private void ApplicationBarIconButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Registration successful! You will receive login password after verification with RTO");
            NavigationService.Navigate(new Uri("/PageLogin.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}