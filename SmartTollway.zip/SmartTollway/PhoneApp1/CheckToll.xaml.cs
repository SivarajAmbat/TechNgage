﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
//using HtmlAgilityPack;

namespace PhoneApp1
{
    public partial class CheckToll : PhoneApplicationPage
    {


        public CheckToll()
        {
            InitializeComponent();
            this.Loaded += CheckToll_Loaded;
        }

        private void CheckToll_Loaded(object sender, RoutedEventArgs e)
        {
            //HtmlAgilityPack.HtmlWeb web = new HtmlWeb();
            //web.LoadCompleted += Web_LoadCompleted;
            //web.LoadAsync("http://nhtis.org/map.htm");

            browser.Source = new Uri("http://nhtis.org/map.htm");
        }

        //private void Web_LoadCompleted(object sender, HtmlDocumentLoadCompleted e)
        //{
        //    //HtmlDocument document = e.Document;
        //    //HtmlNode contentNode = document.DocumentNode.SelectSingleNode("//div[@id='header']");
        //    //browser.NavigateToString(contentNode.WriteTo());
        //    //throw new NotImplementedException();
        //}
    }
}