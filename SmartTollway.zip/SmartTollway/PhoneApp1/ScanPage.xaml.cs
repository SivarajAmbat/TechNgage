﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Devices;
using ZXing;
using System.Windows.Threading;
using System.Windows.Media.Imaging;
using ZXing.Mobile;
using System.Diagnostics;

namespace PhoneApp1
{
    public partial class ScanPage : PhoneApplicationPage
    {            

        private MobileBarcodeScanner _scanner;
        
        public ScanPage()
        {

            InitializeComponent();

            _scanner = new MobileBarcodeScanner(this.Dispatcher);
            _scanner.Dispatcher = this.Dispatcher;

        }


        private void HandleScanResult(Result result)
        {
            string msg = "";
            if (result != null)
                msg = "Your payment of ₹ 60 at Electronic City Flyover is successful";
            else
                msg = "Scan Failed! Try again";

            this.Dispatcher.BeginInvoke(()=> {
                MessageBox.Show(msg);
                NavigationService.Navigate(new Uri("/Switchboard.xaml", UriKind.RelativeOrAbsolute));
            });
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                _scanner.UseCustomOverlay = false;
                _scanner.TopText = "Hold camera up to QR code";
                _scanner.BottomText = "Camera will automatically scan QR code\r\n\rPress the 'Back' button to cancel";

                _scanner.Scan().ContinueWith(t =>
                {
                    if (t.Result != null)
                        HandleScanResult(t.Result);
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

        }


        //void _phoneCamera_AutoFocusCompleted(object sender, CameraOperationCompletedEventArgs e)
        //{
        //    Deployment.Current.Dispatcher.BeginInvoke(delegate ()
        //    {
        //        focusBrackets.Visibility = Visibility.Collapsed;
        //    });
        //}

        //void focus_Tapped(object sender, System.Windows.Input.GestureEventArgs e)
        //{
        //    try
        //    {
        //        if (_phoneCamera != null)
        //        {
        //            if (_phoneCamera.IsFocusAtPointSupported == true)
        //            {
        //                // Determine the location of the tap.
        //                Point tapLocation = e.GetPosition(viewfinderCanvas);

        //                // Position the focus brackets with the estimated offsets.
        //                focusBrackets.SetValue(Canvas.LeftProperty, tapLocation.X - 30);
        //                focusBrackets.SetValue(Canvas.TopProperty, tapLocation.Y - 28);

        //                // Determine the focus point.
        //                double focusXPercentage = tapLocation.X / viewfinderCanvas.ActualWidth;
        //                double focusYPercentage = tapLocation.Y / viewfinderCanvas.ActualHeight;

        //                // Show the focus brackets and focus at point.
        //                focusBrackets.Visibility = Visibility.Visible;
        //                _phoneCamera.FocusAtPoint(focusXPercentage, focusYPercentage);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _phoneCamera.Initialized += new EventHandler<Microsoft.Devices.CameraOperationCompletedEventArgs>(cam_Initialized);
        //    }
        //}


        //void CameraButtons_ShutterKeyHalfPressed(object sender, EventArgs e)
        //{
        //    _phoneCamera.Focus();
        //}


        //protected override void OnNavigatingFrom(System.Windows.Navigation.NavigatingCancelEventArgs e)
        //{
        //    //we're navigating away from this page, we won't be scanning any barcodes
        //    _scanTimer.Stop();

        //    if (_phoneCamera != null)
        //    {
        //        // Cleanup
        //        _phoneCamera.Dispose();
        //        _phoneCamera.Initialized -= cam_Initialized;
        //        CameraButtons.ShutterKeyHalfPressed -= CameraButtons_ShutterKeyHalfPressed;
        //    }
        //}

        //void cam_Initialized(object sender, Microsoft.Devices.CameraOperationCompletedEventArgs e)
        //{
        //    if (e.Succeeded)
        //    {
        //        this.Dispatcher.BeginInvoke(delegate ()
        //        {
        //            _phoneCamera.FlashMode = FlashMode.Off;
        //            _previewBuffer = new WriteableBitmap((int)_phoneCamera.PreviewResolution.Width, (int)_phoneCamera.PreviewResolution.Height);

        //            _barcodeReader = new BarcodeReader();

        //            // By default, BarcodeReader will scan every supported barcode type
        //            // If we want to limit the type of barcodes our app can read, 
        //            // we can do it by adding each format to this list object

        //            //var supportedBarcodeFormats = new List<BarcodeFormat>();
        //            //supportedBarcodeFormats.Add(BarcodeFormat.QR_CODE);
        //            //supportedBarcodeFormats.Add(BarcodeFormat.DATA_MATRIX);
        //            //_bcReader.PossibleFormats = supportedBarcodeFormats;

        //            _barcodeReader.TryHarder = true;

        //            _barcodeReader.ResultFound += _bcReader_ResultFound;
        //            _scanTimer.Start();
        //        });
        //    }
        //    else
        //    {
        //        Dispatcher.BeginInvoke(() =>
        //        {
        //            MessageBox.Show("Unable to initialize the camera");
        //        });
        //    }
        //}

        //void _bcReader_ResultFound(Result obj)
        //{
        //    // If a new barcode is found, vibrate the device and display the barcode details in the UI
        //    //if (!obj.Text.Equals(tbBarcodeData.Text))
        //    //{
        //    VibrateController.Default.Start(TimeSpan.FromMilliseconds(100));
        //    //tbBarcodeType.Text = obj.BarcodeFormat.ToString();
        //    //tbBarcodeData.Text = obj.Text;
        //    //NavigationService.Navigate(new Uri(string.Format("/AddCustomer.xaml?parameter={0}", Uri.EscapeUriString(obj.Text), UriKind.Relative)));
        //    PhoneApplicationService.Current.State["Text"] = obj.Text;
        //    NavigationService.Navigate(new Uri("/PageYouWantToGetResult.xaml", UriKind.Relative));

        //}

        //private void ScanForBarcode()
        //{
        //    //grab a camera snapshot
        //    _phoneCamera.GetPreviewBufferArgb32(_previewBuffer.Pixels);
        //    _previewBuffer.Invalidate();

        //    //scan the captured snapshot for barcodes
        //    //if a barcode is found, the ResultFound event will fire
        //   // _barcodeReader.Decode(_previewBuffer);
        //}

    }
}