﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.ComponentModel;
using System.Windows.Controls.Primitives;
using System.Threading;

namespace PhoneApp1
{
    public partial class Registration : PhoneApplicationPage
    {
        private Popup popup;
        private BackgroundWorker backroungWorker;

        public Registration()
        {
            InitializeComponent();
            cbx.ItemsSource = new int[] { 1, 2, 3, 4, 5 };
            ShowSplash();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Registration successful! You will receive login details after verification with RTO");
            NavigationService.Navigate(new Uri("/LoginPage.xaml", UriKind.RelativeOrAbsolute));

        }
        private void ShowSplash()
        {
            this.popup = new Popup();
            this.popup.Child = new Splash();
            this.popup.IsOpen = true;
            StartLoadingData();
        }
        private void StartLoadingData()
        {
            backroungWorker = new BackgroundWorker();
            backroungWorker.DoWork += new DoWorkEventHandler(backroungWorker_DoWork);
            backroungWorker.RunWorkerCompleted +=
          new RunWorkerCompletedEventHandler(backroungWorker_RunWorkerCompleted);
            backroungWorker.RunWorkerAsync();
        }
        void backroungWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            Thread.Sleep(9000);
        }
        void backroungWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() =>
            {
                this.popup.IsOpen = false;
            });
        }
    }
}